/**
 * Save to Recall — Page Content & Metadata Extractor
 * Precision product image, pricing, and visual content detection for e-commerce.
 */

(() => {
  function upgradeImageUrlToMaxRes(url) {
    if (!url || typeof url !== 'string') return url;
    let u = url.trim();

    // 1. Amazon: strip thumbnail dimensions/tokens to get original uncompressed master
    if (u.includes('media-amazon.com') || u.includes('images-amazon.com') || u.includes('ssl-images-amazon')) {
      u = u.replace(/\._[A-Z0-9_,]+_\.([a-zA-Z]+)(\?.*)?$/i, '.$1$2');
    }
    // 2. Flipkart: upgrade thumbnail dimensions to high-res (1664x1664)
    else if (u.includes('flixcart.com')) {
      u = u.replace(/\/image\/\d+\/\d+\//, '/image/1664/1664/');
    }
    // 3. Shopify: upgrade thumbnail suffixes (_small, _medium, _compact, etc.) to 2048x2048
    else if (u.includes('cdn.shopify.com')) {
      u = u.replace(/_(?:pico|icon|thumb|small|compact|medium|large|grande|\d+x\d+)\.([a-zA-Z]+)(\?.*)?$/i, '_2048x2048.$1$2');
    }
    // 4. Walmart: upgrade odnHeight & odnWidth to 1200
    else if (u.includes('walmartimages.com')) {
      u = u.replace(/odnHeight=\d+&odnWidth=\d+/, 'odnHeight=1200&odnWidth=1200');
    }
    // 5. Target / Scene7: upgrade width and height
    else if (u.includes('scene7.com') || u.includes('target.com')) {
      u = u.replace(/wid=\d+&hei=\d+/, 'wid=1200&hei=1200');
    }
    // 6. Myntra: upgrade dynamic transform to high-res
    else if (u.includes('myntassets.com')) {
      u = u.replace(/\/h_\d+,q_\d+,w_\d+\//, '/h_1440,q_95,w_1080/');
    }
    // 7. AliExpress / Taobao: strip dimension suffix
    else if (u.includes('alicdn.com')) {
      u = u.replace(/_\d+x\d+\.([a-zA-Z]+)(\?.*)?$/i, '.$1$2');
    }
    // 8. Generic thumbnail suffixes
    else {
      u = u.replace(/[-_](?:thumb|thumbnail|small|preview|min)\.([a-zA-Z]+)(\?.*)?$/i, '.$1$2');
    }
    return u;
  }

  function getHighestResSrc(img) {
    if (!img) return '';
    let res = '';
    if (img.dataset && img.dataset.oldHires) res = img.dataset.oldHires;
    else if (img.dataset && img.dataset.zoomImage) res = img.dataset.zoomImage;
    else if (img.dataset && img.dataset.highResImage) res = img.dataset.highResImage;

    // Check Amazon dynamic image JSON
    else if (img.dataset && img.dataset.aDynamicImage) {
      try {
        const dyn = JSON.parse(img.dataset.aDynamicImage);
        const urls = Object.keys(dyn);
        if (urls.length > 0) {
          // Sort by max width
          urls.sort((a, b) => (dyn[b][0] * dyn[b][1]) - (dyn[a][0] * dyn[a][1]));
          res = urls[0];
        }
      } catch (e) {}
    }

    // Check srcset
    if (!res) {
      const srcset = img.getAttribute('srcset');
      if (srcset) {
        const candidates = srcset.split(',').map(s => s.trim().split(/\s+/)).filter(p => p[0]);
        if (candidates.length > 0) {
          res = candidates[candidates.length - 1][0];
        }
      }
    }

    if (!res) res = img.currentSrc || img.src || '';
    return upgradeImageUrlToMaxRes(res);
  }

  function extractProductImage() {
    // 1. IKEA Specific
    const ikeaImg = document.querySelector(
      '.pip-aspect-ratio-image__image, .pip-media-grid__media-image img, [data-testid="pip-image"] img, .pip-image img'
    );
    if (ikeaImg) {
      const src = getHighestResSrc(ikeaImg);
      if (src && !src.includes('data:image')) return src;
    }

    // 2. Pepperfry Specific
    const pfImg = document.querySelector(
      '.vip-carousel-item img, #mainImage, .pdp-main-image img, img.v-carousel-item__image, .carousel-inner .active img, [data-zoom-image]'
    );
    if (pfImg) {
      const src = getHighestResSrc(pfImg);
      if (src && !src.includes('data:image')) return src;
    }

    // 3. Amazon Specific
    const amzImg = document.querySelector(
      '#landingImage, #imgTagWrapperId img, #main-image-container img, #imageBlock img'
    );
    if (amzImg) {
      const src = getHighestResSrc(amzImg);
      if (src && !src.includes('data:image')) return src;
    }

    // 4. Flipkart Specific
    const fkImg = document.querySelector(
      'img._396cs4._3exPp9, img._2r_T1I, ._2E1qG img, div._2usHg1 img'
    );
    if (fkImg) {
      const src = getHighestResSrc(fkImg);
      if (src) return src;
    }

    // 5. Schema.org Product JSON-LD image
    const ldScripts = document.querySelectorAll('script[type="application/ld+json"]');
    for (const script of ldScripts) {
      try {
        const data = JSON.parse(script.textContent);
        const checkItem = (item) => {
          if (!item) return null;
          if (item['@type'] === 'Product' || (Array.isArray(item['@type']) && item['@type'].includes('Product'))) {
            if (item.image) {
              const imgVal = Array.isArray(item.image) ? item.image[0] : (item.image.url || item.image);
              if (typeof imgVal === 'string' && imgVal.startsWith('http')) return imgVal;
            }
          }
          return null;
        };

        if (Array.isArray(data)) {
          for (const it of data) {
            const found = checkItem(it);
            if (found) return found;
          }
        } else if (data['@graph']) {
          for (const it of data['@graph']) {
            const found = checkItem(it);
            if (found) return found;
          }
        } else {
          const found = checkItem(data);
          if (found) return found;
        }
      } catch (e) {}
    }

    // 6. Generic Product & Shopify Selectors
    const genericSelectors = [
      '.product__media img',
      '.product-single__media img',
      '.product-featured-media img',
      '.product-featured-image',
      '.product-image-photo',
      '.product-image-container img',
      '[data-product-image]',
      '.gallery-image img',
      '.pdp-image img'
    ];
    for (const sel of genericSelectors) {
      const el = document.querySelector(sel);
      if (el) {
        const src = getHighestResSrc(el);
        if (src) return src;
      }
    }

    // 7. OpenGraph / Twitter Fallback
    const og = document.querySelector('meta[property="og:image:secure_url"]')?.content ||
               document.querySelector('meta[property="og:image"]')?.content ||
               document.querySelector('meta[name="twitter:image"]')?.content;
    if (og && !og.includes('blank') && !og.includes('logo')) return og;

    // 8. Largest natural content image on the page
    const allImages = Array.from(document.querySelectorAll('img')).filter(i => {
      const w = i.naturalWidth || i.width || 0;
      const h = i.naturalHeight || i.height || 0;
      return w > 200 && h > 200 && !i.src.endsWith('.svg') && !i.src.includes('avatar') && !i.src.includes('banner');
    });
    if (allImages.length > 0) {
      allImages.sort((a, b) => ((b.naturalWidth || 0) * (b.naturalHeight || 0)) - ((a.naturalWidth || 0) * (a.naturalHeight || 0)));
      return allImages[0].src;
    }

    return '';
  }

  function extractPrice() {
    // 1. IKEA Price
    const ikeaPrice = document.querySelector('.pip-temp-price__sr-text, .pip-price__current-price, .pip-price');
    if (ikeaPrice) {
      const match = ikeaPrice.textContent.trim().match(/([$€£₹]\s*[0-9,]+(?:\.[0-9]{2})?|[0-9,]+(?:\.[0-9]{2})?\s*[$€£₹])/);
      if (match) return match[0].trim().replace(/\s+/, '');
    }

    // 2. Pepperfry Price
    const pfPrice = document.querySelector('.v-price-box__price, .v-price-box__offer-price, .vip-price, .pdp-price');
    if (pfPrice) {
      const match = pfPrice.textContent.trim().match(/(?:₹|Rs\.?)\s*[0-9,]+/i);
      if (match) return match[0].trim().replace(/Rs\.?/i, '₹').replace(/\s+/, '');
    }

    // 3. Amazon Price
    const amzPrice = document.querySelector(
      '.a-price .a-offscreen, #priceblock_ourprice, #priceblock_dealprice, #corePrice_desktop .a-offscreen, #corePriceDisplay_desktop_feature_div .a-price .a-offscreen'
    );
    if (amzPrice) {
      const val = amzPrice.textContent.trim();
      if (val) return val.replace(/\s+/, '');
    }

    // 4. Flipkart Price
    const fkPrice = document.querySelector('div._30jeq3._16Jk6v, div._30jeq3, div._16Jk6v');
    if (fkPrice) {
      return fkPrice.textContent.trim().replace(/\s+/, '');
    }

    // 5. Schema.org JSON-LD Offers
    const ldScripts = document.querySelectorAll('script[type="application/ld+json"]');
    for (const script of ldScripts) {
      try {
        const data = JSON.parse(script.textContent);
        const checkOffer = (item) => {
          if (!item || !item.offers) return null;
          const offer = Array.isArray(item.offers) ? item.offers[0] : item.offers;
          if (offer && (offer.price !== undefined)) {
            const curr = offer.priceCurrency || 'USD';
            const symbol = curr === 'USD' ? '$' : (curr === 'INR' ? '₹' : (curr === 'EUR' ? '€' : (curr === 'GBP' ? '£' : curr + ' ')));
            return `${symbol}${offer.price}`;
          }
          return null;
        };

        if (Array.isArray(data)) {
          for (const it of data) {
            const found = checkOffer(it);
            if (found) return found;
          }
        } else if (data['@graph']) {
          for (const it of data['@graph']) {
            const found = checkOffer(it);
            if (found) return found;
          }
        } else {
          const found = checkOffer(data);
          if (found) return found;
        }
      } catch (e) {}
    }

    // 6. Generic Price Selectors
    const priceElem = document.querySelector('[itemprop="price"], .price, .product-price, .sale-price, [data-test="product-price"], .current-price');
    if (priceElem) {
      const text = priceElem.textContent.trim();
      const match = text.match(/(?:[$€£₹]|Rs\.?)\s*[0-9,]+(?:\.[0-9]{2})?/i);
      if (match) return match[0].trim().replace(/Rs\.?/i, '₹').replace(/\s+/, '');
    }

    return '';
  }

  function extractPageMetadata() {
    const selectedText = window.getSelection() ? window.getSelection().toString().trim() : '';
    const canonicalLink = document.querySelector('link[rel="canonical"]');
    const url = canonicalLink ? canonicalLink.href : window.location.href;
    const title = (
      document.querySelector('meta[property="og:title"]')?.content ||
      document.querySelector('h1')?.textContent ||
      document.title ||
      'Saved Page'
    ).trim();

    const description = (
      document.querySelector('meta[property="og:description"]')?.content ||
      document.querySelector('meta[name="description"]')?.content ||
      ''
    ).trim();

    const domain = window.location.hostname.toLowerCase();
    const shoppingKeywords = [
      'ikea.', 'pepperfry.', 'amazon.', 'ebay.', 'etsy.', 'walmart.', 'target.',
      'bestbuy.', 'shopify', 'apple.com', 'nike.com', 'aliexpress.', 'flipkart.',
      'myntra.', 'nykaa.', 'zara.', 'hm.com', 'costco.', 'newegg.', 'wayfair.'
    ];

    const isKnownStore = shoppingKeywords.some(k => domain.includes(k));
    const price = extractPrice();
    const isBuying = isKnownStore || Boolean(price);
    let heroImg = upgradeImageUrlToMaxRes(extractProductImage());

    // Video Detection
    const ytMatch = url.match(/(?:youtube\.com\/(?:watch\?v=|embed\/|shorts\/)|youtu\.be\/)([a-zA-Z0-9_-]{11})/i);
    const vimeoMatch = url.match(/vimeo\.com\/(?:video\/)?([0-9]+)/i);
    const ogVideo = document.querySelector('meta[property="og:video"], meta[property="og:video:url"], meta[property="og:video:secure_url"]')?.content || '';
    const twitterPlayer = document.querySelector('meta[name="twitter:player"]')?.content || '';
    const ogType = (document.querySelector('meta[property="og:type"]')?.content || '').toLowerCase();
    const hasVideoTag = Boolean(document.querySelector('video'));

    let isVideo = false;
    let videoId = '';
    let videoEmbedUrl = '';
    let channel = '';

    // Article Detection
    const articleKeywords = [
      'medium.com', 'substack.com', 'wikipedia.org', 'nytimes.com', 'theverge.com',
      'techcrunch.com', 'wired.com', 'bloomberg.com', 'reuters.com', 'bbc.', 'cnn.',
      'ign.com', 'polygon.com', 'kotaku.com', 'eurogamer.net', 'gamespot.com',
      'dev.to', 'hashnode.', 'github.blog', 'towardsdatascience.com', 'arxiv.org',
      'news', 'blog', 'article', 'post', 'story', 'journal', 'essay', 'review'
    ];
    const hasArticleDomain = articleKeywords.some(k => domain.includes(k) || url.toLowerCase().includes('/article/') || url.toLowerCase().includes('/blog/') || url.toLowerCase().includes('/post/') || url.toLowerCase().includes('/news/') || url.toLowerCase().includes('/story/') || url.toLowerCase().includes('/review'));
    const hasArticleTag = Boolean(document.querySelector('article, [role="article"], .article-body, .post-content, .entry-content, .c-article-body, .story-body'));
    const author = document.querySelector('meta[name="author"], meta[property="article:author"], meta[name="parsely-author"]')?.content ||
      document.querySelector('[rel="author"], .byline, .author-name, .c-byline__author')?.textContent?.trim() || '';

    let cleanParagraphs = [];
    const articleRoot = document.querySelector('article, [role="article"], .article-body, .post-content, .entry-content, .c-article-body, .story-body, main');
    if (articleRoot) {
      cleanParagraphs = Array.from(articleRoot.querySelectorAll('p, h2, h3'))
        .map(p => p.textContent.trim())
        .filter(t => t.length > 28 && !/^(advertisement|cookie|privacy policy|terms of|sign up|subscribe|follow us|all rights reserved|copyright)/i.test(t));
    }
    // If articleRoot had few paragraphs (e.g. IGN where <article> is closed early or in Next.js divs), query entire document
    if (cleanParagraphs.length < 3) {
      cleanParagraphs = Array.from(document.querySelectorAll('article p, main p, .article-content p, .body-copy p, p'))
        .map(p => p.textContent.trim())
        .filter(t => t.length > 28 && !/^(advertisement|cookie|privacy policy|terms of|sign up|subscribe|follow us|all rights reserved|copyright)/i.test(t));
      cleanParagraphs = Array.from(new Set(cleanParagraphs));
    }

    const paragraphs = cleanParagraphs;
    const hasSubstantialText = paragraphs.length >= 2;

    if (ytMatch && ytMatch[1]) {
      isVideo = true;
      videoId = ytMatch[1];
      videoEmbedUrl = `https://www.youtube-nocookie.com/embed/${videoId}?autoplay=1`;
      const ytChannel = document.querySelector('#owner #channel-name, ytd-channel-name, [itemprop="author"] [itemprop="name"]')?.textContent?.trim();
      if (ytChannel) channel = ytChannel;
    } else if (vimeoMatch && vimeoMatch[1]) {
      isVideo = true;
      videoId = vimeoMatch[1];
      videoEmbedUrl = `https://player.vimeo.com/video/${videoId}?autoplay=1`;
    } else if ((ogVideo || twitterPlayer || ogType.includes('video')) && !hasArticleTag && !hasArticleDomain && !hasSubstantialText) {
      isVideo = true;
      videoEmbedUrl = ogVideo || twitterPlayer || '';
    }

    if (isVideo && !heroImg && videoId && ytMatch) {
      heroImg = `https://img.youtube.com/vi/${videoId}/maxresdefault.jpg`;
    }

    const isArticle = !isBuying && !isVideo && (ogType === 'article' || hasArticleTag || hasArticleDomain || hasSubstantialText);

    return {
      title,
      url,
      domain: domain.replace(/^www\./, ''),
      selectedText,
      description,
      heroImg,
      isBuying,
      isArticle,
      isVideo,
      videoId,
      videoEmbedUrl,
      channel: channel || author || domain.replace(/^www\./, ''),
      price,
      author,
      paragraphs,
      articleBody: paragraphs.join('\n\n')
    };
  }

  // Listen for messages from background or popup
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'getPageData') {
      sendResponse(extractPageMetadata());
      return true;
    }
    if (request.action === 'recall_import_memory' && request.memory) {
      window.postMessage({ type: 'RECALL_SAVE_MEMORY', memory: request.memory }, '*');
      sendResponse({ received: true });
      return true;
    }
  });

  // If this active tab IS the Recall Web app, check for pending memories
  const isRecallHost = window.location.hostname.includes('vercel.app') || 
                       window.location.hostname.includes('recall') || 
                       window.location.hostname === 'localhost' ||
                       window.location.hostname === '127.0.0.1';

  if (isRecallHost) {
    const forwardedIds = new Set();

    function drainPendingMemories() {
      try {
        const localGroqKey = localStorage.getItem('recall_groq_api_key');
        if (localGroqKey) {
          chrome.runtime.sendMessage({ action: 'set_groq_key', key: localGroqKey });
        }

        chrome.runtime.sendMessage({ action: 'get_pending_memories' }, (res) => {
          if (chrome.runtime.lastError) return;
          if (res && Array.isArray(res.memories) && res.memories.length > 0) {
            chrome.runtime.sendMessage({ action: 'clear_pending_memories' });
            res.memories.forEach(mem => {
              if (mem && mem.id && !forwardedIds.has(mem.id)) {
                forwardedIds.add(mem.id);
                window.postMessage({ type: 'RECALL_SAVE_MEMORY', memory: mem }, '*');
              }
            });
          }
        });
      } catch (e) {}
    }

    drainPendingMemories();
    window.addEventListener('focus', drainPendingMemories);
    window.addEventListener('message', (ev) => {
      if (ev.data && ev.data.type === 'RECALL_SET_GROQ_KEY' && ev.data.key) {
        chrome.runtime.sendMessage({ action: 'set_groq_key', key: ev.data.key });
      }
    });
    document.addEventListener('visibilitychange', () => {
      if (!document.hidden) drainPendingMemories();
    });
  }
})();
