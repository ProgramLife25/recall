# Save to Recall — Browser Extension

The official Chrome / Edge / Brave / Chromium extension for **Recall Web**.

Allows saving texts, notes, images, buying links, and articles in **one click** directly into your local Recall memory board running at `http://localhost:8088`.

---

## 🚀 How to Install in Chrome / Brave / Edge (One-Time Setup)

1. Open your browser and navigate to the Extensions management page:
   - **Chrome**: `chrome://extensions/`
   - **Brave**: `brave://extensions/`
   - **Edge**: `edge://extensions/`
2. In the top-right corner, toggle **Developer mode** to **ON**.
3. Click the **Load unpacked** button (top left).
4. Select the extension directory:
   `/Users/abhinavtyagi/Documents/Personal work/recall-extension`
5. Done! The **Save to Recall** aperture icon will appear in your browser toolbar (pin it for fast one-click access).

---

## ⚡ Features & How to Use

### 1. One-Click Toolbar Popup
- Click the **Save to Recall** icon in your toolbar on any web page.
- It automatically pulls:
  - High-res hero image / thumbnail
  - Page title
  - Source domain badge
  - **Buying / Product Detection**: If you're on a shopping site (Amazon, eBay, Etsy, Shopify, etc.), it automatically extracts the **price** and tags it with a bright orange **BUYING** badge.
  - **Selected Text**: If you had text selected on the page, it automatically loads it into the note box.
- Type any personal note or thoughts (optional).
- Press **Enter** or click **Save to Recall** — it saves instantly to your local memory board!

### 2. Right-Click Context Menus
Right-click anywhere on the web:
- **Save to Recall**: Saves the current webpage or article.
- **Save Selected Text to Recall**: Right-click on any highlighted quote or paragraph to save it as a note card.
- **Save Image to Recall**: Right-click any photo or image to save it directly to your visual board.
- **Save Link to Recall**: Right-click any hyperlink to bookmark and catalog it.

---

## 🔒 100% Private & On-Device
Zero external cloud servers or trackers. All saves are delivered directly to your local daemon at `http://localhost:8088` and persisted in your local IndexedDB database.
