/**
 * Save to Recall — Popup Controller
 * Connects active tab metadata to local Recall Web server.
 */

const RECALL_SERVER_URL = 'https://recall-web-puce.vercel.app';

document.addEventListener('DOMContentLoaded', async () => {
  const statusEl = document.getElementById('serverStatus');
  const statusText = document.getElementById('statusText');
  const titleInput = document.getElementById('titleInput');
  const sourcePill = document.getElementById('sourcePill');
  const previewImg = document.getElementById('previewImg');
  const buyingBadge = document.getElementById('buyingBadge');
  const priceVal = document.getElementById('priceVal');
  const noteInput = document.getElementById('noteInput');
  const saveBtn = document.getElementById('saveBtn');
  const successOverlay = document.getElementById('successOverlay');
  const successSub = document.getElementById('successSub');

  let currentTabData = {
    title: '',
    url: '',
    domain: '',
    heroImg: '',
    price: '',
    isBuying: false,
    selectedText: '',
    description: ''
  };

  // 1. Check Server Connection / Active Recall App
  async function checkServer() {
    try {
      const allTabs = await chrome.tabs.query({});
      const hasRecallTab = (allTabs || []).some(t => {
        const u = (t.url || '').toLowerCase();
        const title = (t.title || '').toLowerCase();
        return u.includes('recall-web-puce.vercel.app') ||
               u.includes('vercel.app') ||
               u.includes('localhost') ||
               u.includes('127.0.0.1') ||
               title === 'recall' ||
               title.includes('recall —');
      });
      if (hasRecallTab) {
        statusEl.className = 'status-indicator connected';
        statusText.textContent = 'App Ready';
        return true;
      }
      const res = await fetch(`${RECALL_SERVER_URL}/api/inbox`);
      if (res.ok) {
        statusEl.className = 'status-indicator connected';
        statusText.textContent = 'Connected';
        return true;
      }
    } catch (e) {}
    statusEl.className = 'status-indicator connected';
    statusText.textContent = 'Cloud Ready';
    return true;
  }
  checkServer();

  // 2. Fetch Active Tab Info & Content Script Data
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab) {
      currentTabData.url = tab.url || '';
      currentTabData.title = tab.title || '';
      try {
        currentTabData.domain = new URL(tab.url).hostname.replace(/^www\./, '');
      } catch (e) {
        currentTabData.domain = 'web';
      }

      // Pre-fill defaults
      titleInput.value = currentTabData.title;
      sourcePill.textContent = currentTabData.domain;

      // Ask content script for rich metadata (hero image, selected text, price)
      try {
        const response = await chrome.tabs.sendMessage(tab.id, { action: 'getPageData' });
        if (response) {
          Object.assign(currentTabData, response);

          if (response.title) titleInput.value = response.title;
          if (response.selectedText) {
            noteInput.value = response.selectedText;
          } else if (response.description) {
            noteInput.placeholder = response.description.slice(0, 100) + '…';
          }

          if (response.heroImg) {
            previewImg.src = response.heroImg;
            previewImg.onload = () => previewImg.classList.add('loaded');
          }

          if (response.isBuying && response.price) {
            buyingBadge.style.display = 'inline-flex';
            priceVal.textContent = response.price;
          }
        }
      } catch (scriptErr) {
        // Content script might not be injected on special pages (chrome://, etc.)
        if (tab.favIconUrl) {
          previewImg.src = tab.favIconUrl;
          previewImg.onload = () => previewImg.classList.add('loaded');
        }
      }
    }
  } catch (err) {
    console.warn('Error loading tab info:', err);
  }

  // 3. Save to Recall
  async function saveItem() {
    saveBtn.disabled = true;
    saveBtn.style.opacity = '0.7';

    const title = titleInput.value.trim() || currentTabData.title || 'Saved Page';
    const body = noteInput.value.trim();
    const isBuying = currentTabData.isBuying || Boolean(currentTabData.price);
    const isVideo = Boolean(currentTabData.isVideo);
    const isNote = Boolean(body && !currentTabData.heroImg && !isVideo);
    const isArticle = (currentTabData.isArticle || !isBuying) && !isNote && !isVideo;
    const tags = ['extension'];

    if (isBuying) {
      tags.push('buying', 'product');
    } else if (isVideo) {
      tags.push('video', 'watch');
    } else if (isArticle) {
      tags.push('article', 'reading');
    }
    if (currentTabData.domain) {
      tags.push(currentTabData.domain);
    }
    if (isNote) {
      tags.push('note');
    }

    const payload = {
      type: isBuying ? 'Product' : (isVideo ? 'Video' : (isNote ? 'Note' : 'Article')),
      title,
      source: currentTabData.url,
      heroImg: currentTabData.heroImg,
      body,
      tldr: body || currentTabData.description || title,
      price: currentTabData.price || '',
      isBuying,
      isArticle,
      isVideo,
      videoId: currentTabData.videoId || '',
      videoEmbedUrl: currentTabData.videoEmbedUrl || '',
      channel: currentTabData.channel || '',
      isNote,
      author: currentTabData.author || '',
      publication: currentTabData.domain || '',
      paragraphs: currentTabData.paragraphs || [],
      articleBody: currentTabData.articleBody || '',
      tags
    };

    try {
      // 1. Send memory to background worker to broadcast to open Recall tab or queue for next open
      await chrome.runtime.sendMessage({ action: 'save_memory', memory: payload });

      // 2. Also send to hosted Vercel API endpoint and local server
      fetch(`${RECALL_SERVER_URL}/api/save`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }).catch(() => {});

      fetch('http://localhost:8088/api/save', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }).catch(() => {});

      successSub.textContent = isBuying ? 'Product saved with price' : 'Added to your Recall memories';
      successOverlay.classList.add('visible');
      setTimeout(() => {
        window.close();
      }, 1000);
    } catch (e) {
      console.warn('Save error:', e);
      successSub.textContent = 'Saved to Recall';
      successOverlay.classList.add('visible');
      setTimeout(() => {
        window.close();
      }, 1000);
    }
  }

  saveBtn.addEventListener('click', saveItem);

  // Keyboard shortcut: Cmd+Enter or Enter to save
  window.addEventListener('keydown', (e) => {
    if ((e.metaKey || e.ctrlKey) && e.key === 'Enter') {
      e.preventDefault();
      saveItem();
    }
  });
});
