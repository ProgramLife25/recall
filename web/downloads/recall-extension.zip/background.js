/**
 * Save to Recall — Background Service Worker
 * Handles right-click context menus, badge indicators, and background API saves.
 */

const RECALL_SERVER_URL = 'https://recall-web-puce.vercel.app';

// Create Context Menus
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: 'recall_save_page',
    title: 'Save to Recall',
    contexts: ['page']
  });

  chrome.contextMenus.create({
    id: 'recall_save_selection',
    title: 'Save Selected Text to Recall',
    contexts: ['selection']
  });

  chrome.contextMenus.create({
    id: 'recall_save_image',
    title: 'Save Image to Recall',
    contexts: ['image']
  });

  chrome.contextMenus.create({
    id: 'recall_save_link',
    title: 'Save Link to Recall',
    contexts: ['link']
  });
});

// Flash Badge Status
function showBadge(text, color = '#28c840') {
  chrome.action.setBadgeText({ text });
  chrome.action.setBadgeBackgroundColor({ color });
  setTimeout(() => {
    chrome.action.setBadgeText({ text: '' });
  }, 2500);
}

// Broadcast memory directly to any active Recall Web tabs
async function broadcastToRecallTabs(payload) {
  try {
    const allTabs = await chrome.tabs.query({});
    const recallTabs = (allTabs || []).filter(t => {
      const url = (t.url || '').toLowerCase();
      const title = (t.title || '').toLowerCase();
      return url.includes('recall-web-puce.vercel.app') ||
             url.includes('vercel.app') ||
             url.includes('localhost') ||
             url.includes('127.0.0.1') ||
             title === 'recall' ||
             title.includes('recall —');
    });

    if (recallTabs.length === 0) return false;

    let delivered = false;
    for (const tab of recallTabs) {
      if (!tab.id) continue;
      // 1. Send via content script runtime message
      try {
        await chrome.tabs.sendMessage(tab.id, { action: 'recall_import_memory', memory: payload });
        delivered = true;
      } catch (e) {}

      // 2. Also inject directly via scripting API for guaranteed instant delivery
      if (chrome.scripting && tab.id) {
        try {
          await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            func: (mem) => {
              window.postMessage({ type: 'RECALL_SAVE_MEMORY', memory: mem }, '*');
              document.dispatchEvent(new CustomEvent('recall-import-memory', { detail: mem }));
            },
            args: [payload]
          });
          delivered = true;
        } catch (scriptErr) {}
      }
    }
    return delivered;
  } catch (err) {
    console.warn('[broadcastToRecallTabs Notice]', err);
    return false;
  }
}

// Queue memory locally in extension storage if Recall tab was closed
async function enqueuePending(payload) {
  return new Promise(resolve => {
    chrome.storage.local.get(['recall_pending_memories'], (res) => {
      const list = res.recall_pending_memories || [];
      if (!list.some(m => m.id === payload.id)) {
        list.push(payload);
      }
      chrome.storage.local.set({ recall_pending_memories: list }, resolve);
    });
  });
}

// Save Memory to Recall
async function sendToRecall(payload) {
  if (!payload.id) {
    payload.id = 'mem_' + Date.now() + '_' + Math.random().toString(36).substr(2, 6);
  }
  if (!payload.timestamp) {
    payload.timestamp = new Date().toISOString();
  }

  // 1. Deliver directly to any open Recall Web tab
  const delivered = await broadcastToRecallTabs(payload);

  // 2. Always queue in storage so even if tab was in background, next focus syncs it
  await enqueuePending(payload);

  // 3. Post to Vercel API endpoint and local server
  try {
    fetch(`${RECALL_SERVER_URL}/api/save`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    }).catch(() => {});
  } catch (e) {}

  try {
    fetch('http://localhost:8088/api/save', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    }).catch(() => {});
  } catch (e) {}

  showBadge('✓', '#28c840');
  return true;
}

// Runtime message listener for Popup and Content Scripts
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'set_groq_key' && request.key) {
    chrome.storage.local.set({ recall_groq_api_key: request.key });
    return true;
  }
  if (request.action === 'save_memory' && request.memory) {
    sendToRecall(request.memory).then(success => sendResponse({ success }));
    return true;
  }
  if (request.action === 'get_pending_memories') {
    chrome.storage.local.get(['recall_pending_memories'], (res) => {
      sendResponse({ memories: res.recall_pending_memories || [] });
    });
    return true;
  }
  if (request.action === 'clear_pending_memories') {
    chrome.storage.local.set({ recall_pending_memories: [] }, () => {
      sendResponse({ cleared: true });
    });
    return true;
  }
});

/**
 * Ultra-Fast Dense Vision & OCR Analysis via Groq (qwen/qwen3.8-27b)
 */
async function analyzeImageWithGroqExtension(imageUrl, apiKey) {
  if (!imageUrl || !apiKey) return null;

  // Convert HTTP/HTTPS image URL to base64 data URI because Groq Vision strictly requires data URLs
  let dataUrl = imageUrl;
  if (typeof imageUrl === 'string' && (imageUrl.startsWith('http://') || imageUrl.startsWith('https://'))) {
    try {
      const resp = await fetch(imageUrl);
      if (resp.ok) {
        const blob = await resp.blob();
        dataUrl = await new Promise((resolve) => {
          const reader = new FileReader();
          reader.onloadend = () => resolve(reader.result);
          reader.onerror = () => resolve(imageUrl);
          reader.readAsDataURL(blob);
        });
      }
    } catch (fetchErr) {
      console.warn('[Extension Image Fetch Error]', fetchErr);
    }
  }

  const prompt = `Analyze this image thoroughly for Recall, a visual memory and personal search app.
Your objective is to make this image discoverable under ANY relevant search query.
Return ONLY a valid strict JSON object with NO markdown, NO backticks, and NO extra text:
{
  "title": "A precise, natural title. If a book cover, exact book title + author/volume. If an animal/creature, species + action + environment (e.g. 'Male African Lion Resting on Golden Savanna Grass'). If a product, exact brand + product. If a photo, primary subject + setting.",
  "ocrText": "Extract ALL visible text verbatim. Every single word, book title, author, publisher, quote, subtitle, chapter, brand label, sign, or stamp.",
  "tldr": "A detailed 2-3 sentence descriptive caption summarizing the primary subject, secondary elements, physical appearance, colors, lighting, setting/backdrop, actions, and overall mood.",
  "tags": ["15-20 lowercase search keywords covering: primary subject, species/category, secondary objects, colors, environment/scene, actions, materials, art style, mood, synonyms (e.g. lion, african-lion, feline, predator, cat, wildlife, savanna, safari, grassland, resting, golden, mane, nature, outdoors, mammal, wild)"],
  "isBook": true or false,
  "hasAnimals": true or false,
  "isQuote": true or false,
  "primarySubject": "Specific noun (e.g. lion, book, quote, sneakers)",
  "author": "Author name if book or quote, else empty string",
  "action": "Action if animal or person is moving (e.g. resting, walking, running, sitting, standing), else empty string",
  "scene": "Environment (e.g. savanna, safari, nature, office, studio, outdoors), else empty string"
}`;

  try {
    if (typeof dataUrl === 'string' && dataUrl.startsWith('data:')) {
      const res = await fetch('https://api.groq.com/openai/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${apiKey.trim()}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          model: 'qwen/qwen3.8-27b',
          messages: [
            {
              role: 'user',
              content: [
                { type: 'text', text: prompt },
                { type: 'image_url', image_url: { url: dataUrl } }
              ]
            }
          ],
          reasoning_effort: 'none',
          max_completion_tokens: 1024,
          temperature: 0.1
        })
      });
      if (res.ok) {
        const json = await res.json();
        const rawContent = json.choices?.[0]?.message?.content;
        if (rawContent) {
          const match = rawContent.match(/\{[\s\S]*\}/);
          if (match) {
            const parsed = JSON.parse(match[0]);
            const tagsSet = new Set((parsed.tags || []).map(t => String(t).toLowerCase().trim()));
            if (parsed.primarySubject) tagsSet.add(String(parsed.primarySubject).toLowerCase().trim());
            if (parsed.action) tagsSet.add(String(parsed.action).toLowerCase().trim());
            if (parsed.scene) tagsSet.add(String(parsed.scene).toLowerCase().trim());
            parsed.tags = Array.from(tagsSet).filter(Boolean);
            return parsed;
          }
        }
      }
    }
  } catch (err) {
    console.warn('[Extension Direct Groq Vision Notice]', err.message || err);
  }

  // Fallback to Recall backend server proxy
  try {
    const proxyRes = await fetch(`${RECALL_SERVER_URL}/api/ai/groq-analyze`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey.trim()}`
      },
      body: JSON.stringify({
        image: imageUrl,
        apiKey: apiKey.trim()
      })
    });
    if (proxyRes.ok) {
      const proxyJson = await proxyRes.json();
      if (proxyJson.success && proxyJson.data) return proxyJson.data;
    }
  } catch (proxyErr) {
    console.warn('[Extension Server Proxy Notice]', proxyErr.message || proxyErr);
  }

  return null;
}

/**
 * Fast Text Intelligence via Groq (qwen/qwen3.8-27b)
 * Classifies text into Quote or Note, extracts concise title, summary, quote attribution, and tags
 */
async function analyzeTextWithGroqExtension(text, apiKey) {
  if (!text || !apiKey) return null;
  try {
    const prompt = `Analyze this text for Recall (a personal visual memory app).
Determine if it is a Quote (inspirational saying, proverb, aphorism, or attributed thought) or a Note / Idea.
Extract a concise title (3-7 words), a 1-2 sentence summary, and semantic tags.
Return ONLY a valid strict JSON object:
{
  "isQuote": true or false,
  "quoteText": "Verbatim quote if quote, else empty string",
  "quoteAttribution": "Author or source if quote, else empty string",
  "title": "A short descriptive title (3-7 words)",
  "tldr": "A 1-2 sentence concise summary",
  "tags": ["3", "to", "6", "relevant", "lowercase", "tags"]
}

Text:
"""${text.slice(0, 3500)}"""`;

    const res = await fetch('https://api.groq.com/openai/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey.trim()}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: 'qwen/qwen3.8-27b',
        messages: [{ role: 'user', content: prompt }],
        temperature: 0.1,
        max_completion_tokens: 450,
        response_format: { type: 'json_object' }
      })
    });

    if (res.ok) {
      const json = await res.json();
      const rawContent = json.choices?.[0]?.message?.content;
      if (rawContent) {
        const match = rawContent.match(/\{[\s\S]*\}/);
        if (match) return JSON.parse(match[0]);
      }
    }
  } catch (err) {
    console.warn('[Extension Groq Text Notice]', err.message || err);
  }
  return null;
}

// Context Menu Click Handler
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  const pageUrl = info.pageUrl || tab?.url || '';
  const pageTitle = tab?.title || 'Saved Item';

  // 1. Save Image (with AI Groq Vision enhancement)
  if (info.menuItemId === 'recall_save_image') {
    const imgUrl = info.srcUrl;
    chrome.storage.local.get(['recall_groq_api_key'], async (stored) => {
      const groqKey = stored.recall_groq_api_key;
      let groqMeta = null;
      if (groqKey) {
        showBadge('AI…', '#f59e0b');
        try {
          groqMeta = await analyzeImageWithGroqExtension(imgUrl, groqKey);
        } catch(e) {}
      }

      const isGoogleSearch = pageTitle.includes('Google Search') || pageTitle.includes('Google Images') || pageTitle.toLowerCase().includes('google');
      const cleanTitle = groqMeta?.title || (isGoogleSearch ? 'Saved Image' : pageTitle);

      await sendToRecall({
        type: groqMeta?.isBook ? 'Book' : (groqMeta?.isQuote ? 'Quote' : 'Web image'),
        title: cleanTitle,
        source: pageUrl,
        heroImg: imgUrl,
        tldr: groqMeta?.tldr || (isGoogleSearch ? 'A visual memory saved from Google Images' : `Image from ${pageTitle}`),
        ocrText: groqMeta?.ocrText || '',
        tags: Array.from(new Set([
          'image', 'extension', 'context-menu',
          ...(groqMeta?.tags || []),
          ...(groqMeta?.primarySubject ? [groqMeta.primarySubject.toLowerCase()] : []),
          ...(groqMeta?.action ? [groqMeta.action.toLowerCase()] : []),
          ...(groqMeta?.scene ? [groqMeta.scene.toLowerCase()] : [])
        ]))
      });
    });
    return;
  }

  // 2. Save Selected Text / Note (Enhanced with Groq AI Intelligence)
  if (info.menuItemId === 'recall_save_selection') {
    const selectedText = info.selectionText || '';
    chrome.storage.local.get(['recall_groq_api_key'], async (stored) => {
      const groqKey = stored.recall_groq_api_key;
      let textMeta = null;
      if (groqKey) {
        showBadge('AI…', '#f59e0b');
        try {
          textMeta = await analyzeTextWithGroqExtension(selectedText, groqKey);
        } catch(e) {}
      }

      const isQuote = Boolean(textMeta?.isQuote);
      await sendToRecall({
        type: isQuote ? 'Quote' : 'Note',
        contentType: isQuote ? 'Quote' : 'Note',
        isQuote: isQuote,
        isNote: !isQuote,
        title: textMeta?.title || (selectedText.length > 36 ? selectedText.slice(0, 34) + '…' : selectedText),
        body: isQuote ? (textMeta?.quoteText || selectedText) : selectedText,
        quote: isQuote ? (textMeta?.quoteText || selectedText) : '',
        attribution: textMeta?.quoteAttribution || '',
        quoteAttribution: textMeta?.quoteAttribution || '',
        source: pageUrl,
        tldr: textMeta?.tldr || selectedText,
        tags: Array.from(new Set([
          isQuote ? 'quote' : 'note',
          'extension',
          ...(textMeta?.tags || [])
        ]))
      });
    });
    return;
  }

  // 3. Save Link
  if (info.menuItemId === 'recall_save_link') {
    const linkUrl = info.linkUrl || '';
    const isVid = /(?:youtube\.com\/(?:watch\?v=|embed\/|shorts\/)|youtu\.be\/|vimeo\.com|\.mp4|\.webm|\.mov)/i.test(linkUrl);
    await sendToRecall({
      type: isVid ? 'Video' : 'Article',
      isArticle: !isVid,
      isVideo: isVid,
      title: linkUrl,
      source: linkUrl,
      tldr: `${isVid ? 'Video' : 'Link'} from ${pageTitle}`,
      tags: isVid ? ['video', 'link', 'extension'] : ['link', 'article', 'reading', 'extension']
    });
    return;
  }

  // 4. Save Page
  if (info.menuItemId === 'recall_save_page') {
    try {
      let response = null;
      try {
        response = await chrome.tabs.sendMessage(tab.id, { action: 'getPageData' });
      } catch (err) {
        // If content script was not ready, try injecting it dynamically
        if (chrome.scripting && tab?.id) {
          try {
            await chrome.scripting.executeScript({
              target: { tabId: tab.id },
              files: ['content.js']
            });
            response = await chrome.tabs.sendMessage(tab.id, { action: 'getPageData' });
          } catch (injErr) {
            console.warn('[Save to Recall] Dynamic injection fallback failed:', injErr);
          }
        }
      }

      if (response) {
        const isBuying = Boolean(response.isBuying || response.price);
        const isVideo = Boolean(response.isVideo);
        const isArticle = Boolean(!isBuying && !isVideo && (response.isArticle || (response.paragraphs && response.paragraphs.length > 0)));

        await sendToRecall({
          type: isBuying ? 'Product' : (isVideo ? 'Video' : (isArticle ? 'Article' : 'Web image')),
          title: response.title || pageTitle,
          source: response.url || pageUrl,
          heroImg: response.heroImg || '',
          price: response.price || '',
          isBuying: isBuying,
          isArticle: isArticle,
          isVideo: isVideo,
          videoId: response.videoId || '',
          videoEmbedUrl: response.videoEmbedUrl || '',
          channel: response.channel || '',
          author: response.author || '',
          publication: response.domain || '',
          paragraphs: response.paragraphs || [],
          articleBody: response.articleBody || '',
          subtitle: response.description || '',
          tldr: response.description || response.title || pageTitle,
          body: response.selectedText || response.articleBody || response.description || '',
          tags: isBuying
            ? ['buying', 'product', 'shopping', response.domain].filter(Boolean)
            : (isVideo
              ? ['video', 'watch', 'extension', response.domain].filter(Boolean)
              : ['article', 'reading', 'extension', response.domain].filter(Boolean))
        });
        return;
      }
    } catch (e) {
      console.warn('[Save to Recall] Error extracting page data:', e);
    }

    // Fallback if content script message fails
    const isVid = /(?:youtube\.com\/(?:watch\?v=|embed\/|shorts\/)|youtu\.be\/|vimeo\.com)/i.test(pageUrl);
    await sendToRecall({
      type: isVid ? 'Video' : 'Article',
      isArticle: !isVid,
      isVideo: isVid,
      title: pageTitle,
      source: pageUrl,
      tldr: pageTitle,
      tags: isVid ? ['page', 'video', 'extension'] : ['page', 'article', 'extension']
    });
  }
});
